import { redirect } from "next/navigation"
export default function Page() { redirect("/it-dashboard/tasks") }
